export class Country {
    public _id:string;
    public name:string;
    public capital:string;
}
